import { ApiError } from "../utils/ApiError.js";
import { ApiResponse} from "../utils/ApiResponse.js";
import {Lead} from "../models/lead.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import axios from "axios";
import {sendMail} from "../helper/mailer.js";
axios.defaults.withCredentials = true
const generateTokens= async(userId)=>{
    try {
        const lead = await Lead.findById(userId);
        const token = await lead.generateToken();

        await lead.save({validateBeforeSave: false})
        return token;
    } catch (error) {
        return new ApiError(500, "Something went wrong")
    }
}



const signUp = asyncHandler(async(req, res)=>{

    const { role, email,password, } = req.body;
    if (!(role && email && password)) {
        return res.status(401).send(new ApiError(400, "All fields are required"))
    }
    if (!email.includes("@")) {
        return res.status(400).send(new ApiError(400, "Email is not valid"))
    }
    if (password.length<6) {
        return res.status(400).send(new ApiError(400, "Password should be atleast 6 characters"))
    }

    const LeadExist = await Lead.findOne({ email });

    if (LeadExist) {
        return res.status(400).send(new ApiError(400, "Lead already exist"));
    }

    const lead = await Lead.create({
        role,
        email,
        password
    });

    const createdLead = await Lead.findById(lead._id).select("-password")



    if (!createdLead) {
        return res.status(500).send(new ApiError(500, "Something went wrong while creating user"))
    }

    //send verification mail

    await sendMail({email, emailType: "VERIFY", userId: createdLead._id});

    return res.status(200).json(new ApiResponse(200, lead, "User created successfully"))
})

const signIn = asyncHandler(async(req, res)=>{

    const { email, password } = req.body;
    if (!(email && password)) {
        return res.status(400).send(new ApiError(400, "All fields are required"))
    }
    const leadExist = await Lead.findOne({ email });

    if (!leadExist) {
        return res.status(400).send(new ApiError(400, "User does not exist"));
    }
    const validLead = await leadExist.comparePassword(password);
    if (!validLead) {
        return res.status(400).send(new ApiError(400, "Invalid password"));
    }
    console.log(leadExist._id)
    const token = await generateTokens(leadExist._id);

    const loggedLead = await Lead.findById(leadExist._id).select("-password");
    const option = {
        httpOnly: false,
        secure: true
    }
    return res.status(200).cookie('token', token, option).json(new ApiResponse(200, {user: loggedLead, token}, "User logged in successfully"))

})

const verifyEmail= asyncHandler(async(req, res)=>{
    const {token} = req.body;
    console.log(token)
    const lead = await Lead.findOne({verificationToken: token, verificationTokenExpiry: {$gt: Date.now()}});
    if (!lead) {
        return res.status(400).send(new ApiError(400, "Invalid user"));
    }
    lead.isVerified = true;
    lead.verificationToken = undefined;
    lead.verificationTokenExpiry = undefined;

    await lead.save();

    return res.status(200).json(new ApiResponse(200, {}, "Email verified successfully"))

})

const signOut = asyncHandler((req, res)=>{
    const option = {
        httpOnly: false,
        secure: true,
        sameSite: 'none'
    }
    return res.status(200).clearCookie('token', option).json(new ApiResponse(200, {}, "User logged out successfully"));
})

export {signUp, signIn, signOut, verifyEmail}
