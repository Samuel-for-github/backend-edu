import { ApiError } from "../utils/ApiError.js";
import { ApiResponse} from "../utils/ApiResponse.js";
import {User} from "../models/User.js"

import { asyncHandler } from "../utils/asyncHandler.js";
const generateTokens= async(userId)=>{
    try {
        const user = await User.findById(userId);
        const token = await user.generateToken();
        await user.save({validateBeforeSave: false})
        return token;
    } catch (error) {
        return new ApiError(500, "Wrinf went")
    }
}

const register = asyncHandler(async(req, res)=>{
   

    
    // @route    POST api/users
    // @desc     Register user
    // @access   Public
        const { name, school, class: className, email, phone, password } = req.body;
        if (!(name && school && className && email && phone && password)) {
            return res.status(401).send(new ApiError(400, "All fields are required"))
        }
        if (!email.includes("@")) {
            return res.status(400).send(new ApiError(400, "Email is not valid"))
        }
        if (password.length<6) {
            return res.status(400).send(new ApiError(400, "Password should be atleast 6 characters"))
        }
        
          const userExist = await User.findOne({ email });
    
          if (userExist) {
            return res.status(400).send(new ApiError(400, "User alrady exist"));
          }
    
         const user = await User.create({
            name,
            school,
            class: className,
            email,
            phone,
            password,
          });
        
          const createdUser = await User.findById(user._id).select("-password")
          if (!createdUser) {
            return res.status(500).send(new ApiError(500, "Something went wrong while creating user"))
          }
          return res.status(200).json(new ApiResponse(200, user, "User created successfully"))
      })
    
const loginUser = asyncHandler(async(req, res)=>{
    
    const { email, password } = req.body;
    if (!(email && password)) {
        return res.status(400).send(new ApiError(400, "All fields are required"))
    }
    const userExist = await User.findOne({ email });
    
    if (!userExist) {
      return res.status(400).send(new ApiError(400, "User does not exist"));
    }
    const validUser = await userExist.comparePassword(password);
    if (!validUser) {
        return res.status(400).send(new ApiError(400, "Invalid password"));
      }
      const token = await generateTokens(userExist._id);
      const loggedUser = await User.findById(userExist._id).select("-password");
      const option = {
        httpOnly: false,
        secure: true
      }
      return res.status(200).cookie('token', token, option).json(new ApiResponse(200, {user: loggedUser, token}, "User logged in successfully"))

})

const logoutUser = asyncHandler((req, res)=>{
  const option = {
    httpOnly: false,
    secure: true,
    sameSite: 'none'
  }
  return res.status(200).clearCookie('token', option).json(new ApiResponse(200, {}, "User logged out successfully"));
})

const user = asyncHandler(async(req, res)=>{
  console.log(req.user);
  const user = await User.findById(req.user._id).select('-password');
  if (!user) {
    return res.status(400).send(new ApiError(400, "No user found"))
  } 
  res.status(200).json(new ApiResponse(200, user));
})

const saveApplication = asyncHandler(async (req, res) => {
  const userId = req.user._id;
  const { personalInformation } = req.body;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json(new ApiError(404, "User not found"));
    }

    user.application.personalInformation = personalInformation;
    await user.save();

    res.status(200).json(new ApiResponse(200, user, "Application details saved successfully"));
  } catch (error) {
    res.status(500).json(new ApiError(500, error.message));
  }
});

const googleUser = asyncHandler(async (req, res)=>{

    if (!user) {
        return res.status(400).send(new ApiError(400, "No user found"))
    }
    res.status(200).json(new ApiResponse(200, req.user))

})


export {register, loginUser, user, logoutUser, saveApplication, googleUser}
