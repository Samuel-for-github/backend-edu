import {Router} from "express"

import {signUp, signIn, signOut, verifyEmail} from "../controllers/lead.controller.js";
const router = Router();

router.route("/signUp").post(signUp);
router.route("/signIn").post(signIn);
router.route("/signOut").post(signOut);
router.route("/verify").post(verifyEmail);
export default router;